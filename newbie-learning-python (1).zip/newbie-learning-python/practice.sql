-- Table creation
CREATE TABLE customers (
  id INT PRIMARY KEY, 
  name TEXT,
  city TEXT, 
  created_at DATE
);

-- Insert sample data 
INSERT INTO customers (id, name, city, created_at) VALUES
(1, 'Billy', 'Fairfax', '2023-01-01'), 
(2, 'Bob', 'Chantilly', '2023-01-02'),
(3, 'Thornton', 'Centreville', '2023-01-03');

-- Basic query
SELECT * FROM customers;

-- Filter 
SELECT name FROM customers WHERE city = 'Fairfax';

-- Count
SELECT COUNT(*) FROM customers

-- Order
SELECT * FROM customers ORDER BY created_at DESC;